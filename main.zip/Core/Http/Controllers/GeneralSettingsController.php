<?php

namespace Core\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Cache;
use Core\Repositories\SettingsRepository;
use Core\Http\Requests\GeneralSettingsRequest;

class GeneralSettingsController extends Controller
{
    protected $settings_repository;

    public function __construct(SettingsRepository $settings_repository)
    {
        $this->settings_repository = $settings_repository;
        $this->middleware(['theme' . 'looks', 'licen'. 'se']);
    }

    /**
     * Redirect to general settings page
     */
    public function generalSettings()
    {
        $data = [
            'tl_general_settings.name',
            'tl_general_settings_has_values.settings_id',
            'tl_general_settings_has_values.value'
        ];

        $media_settings_value = $this->settings_repository->getSettingsData($data);
        $data = [];
        
        for ($i = 0; $i < sizeof($media_settings_value); $i++) {
            $data[$media_settings_value[$i]->name] = $media_settings_value[$i]->value;
        }
        
        return view('core::base.general_settings.settings', compact('data'));
    }

    /**
     * store general settings
     *
     * @param  GeneralSettingsRequest $request
     * @return mixed
     */
    public function storeGeneralSettings(GeneralSettingsRequest $request)
    {
        try {
            $all_request = $request->all();
            $data = [];
            $settings_id = [];
            foreach ($all_request as $key => $value) {
                if ($key != '_token') {
                    array_push($data, [
                        'settings_id' => getGeneralSettingId($key),
                        'value' => xss_clean($value)
                    ]);
                    array_push($settings_id, getGeneralSettingId($key));
                }
            }

            if (isset($request['default_timezone'])) {
                setEnv('APP_TIMEZONE', str_replace(' ', '', $request['default_timezone']));
            }

            DB::table('tl_general_settings_has_values')->whereIn('settings_id', $settings_id)->delete();
            DB::table('tl_general_settings_has_values')->insert($data);
            Cache::forget('general-settings');
            Cache::forget('default-lang');
            session()->put('locale', getDefaultLang());

            toastNotification('success', translate('General settings updated successfully'));
            return redirect()->route('core.general.settings');
        } catch (\Exception $ex) {
            toastNotification('success', translate('Unable to update general settings'));
            return redirect()->route('core.general.settings');
        }
    }
}
